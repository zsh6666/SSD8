package proxy;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.net.Socket;
import java.io.UnsupportedEncodingException;

/**
 * RequestProcessor是一个代理服务器的类，它从客户端转发请求并从目标获取响应
 * 
 * @author ZSH
 * 
 */
public class RequestProcessor {

    /**
     * 缓冲区大小为8192字节
     */
    private static int buffer_size = 8192;

    /**
     * Unix风格换行符
     */
    private static String CRLF = "\r\n";

    /**
     * 响应存储在字节数组中
     */
    private byte[] buffer;
    
    /**
     * 存储从服务器获取的Header
     */
    private StringBuffer header = null;
    
    /**
     * 存储从服务器获得的Response
     */
    private StringBuffer response = null;

    /**
     * 连接目标服务器的套接字
     */
    private Socket proxySocket = null;

    /**
     * 输入输出流
     */
    BufferedOutputStream sout = null;
    BufferedInputStream sin = null;

    /**
     * RequestProcessor的构造函数。
     */
    public RequestProcessor() {
        buffer = new byte[buffer_size];
        header = new StringBuffer();
        response = new StringBuffer();
    }

    /**
     * 建立到目标的连接
     *
     * @param host 
     * @param port 
     */
    public void connect(String host, int port) throws Exception {
        /**
         * 创建带有主机host和目标端口port的套接字 
         */
        proxySocket = new Socket(host, port);

        /**
         * 创建输出流
         */
        sout = new BufferedOutputStream(proxySocket.getOutputStream());

        /**
         * 创建输入流
         */
        sin = new BufferedInputStream(proxySocket.getInputStream());
    }

    /**
     *
     * 处理对目标的GET请求。
     *
     * @param request
     * @param host
     * @throws Exception
     */
    public void processGetRequest(String request, String host, int hport) throws Exception {
        /**
         * 将请求发送到服务器
         */
        request += CRLF;
        request += "From: " + host + ":" + String.valueOf(hport) + CRLF;
        request += "User-Agent: HTTPTool/1.0" + CRLF;
        request += "Connection: Close" + CRLF + CRLF;
        System.out.println(request);
        buffer = request.getBytes();
        sout.write(buffer, 0, request.length());
        sout.flush();
        processResponse();
    }

    /**
     * 处理服务器响应
     *
     * @throws Exception
     */
    public void processResponse() throws Exception {
        int last = 0, c = 0;
        boolean moreMsg = true;
        while (moreMsg && ((c = sin.read()) != -1)) {
            switch (c) {
                case '\r':
                    break;
                case '\n':
                    if (c == last) {
                        moreMsg = false;
                        break;
                    }
                    last = c;
                    header.append("\n");
                    break;
                default:
                    last = c;
                    header.append((char) c);
            }
        }
        while (sin.read(buffer) != -1) {
            response.append(new String(buffer, "iso-8859-1"));
        }
    }

    /**
     * 获取响应头
     */
    public String getHeader() {
        return header.toString();
    }

    /**
     * 获取服务器的响应.
     * @throws UnsupportedEncodingException 
     */
    public String getResponse() throws UnsupportedEncodingException {
        return response.toString();
    }

    /**
     * 关闭所有打开的连接--套接字和流
     */
    public void close() throws Exception {
        proxySocket.close();
        sin.close();
        sout.close();
    }
}

