package proxy;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * ProxyServer代理服务器
 * 
 * @author ZSH
 *
 */
public class ProxyServer {
    /**
     * 代理服务器端口 8000.
     */
    private static final int PORT = 8000;

    /**
     * 设置线程池.
     */
    private static ExecutorService executorService;

    /**
     * 设置处理器CPU的数目.
     */
    private static final int POOLSIZE = 4;

    /**
     * 服务器socket连接
     */
    private static ServerSocket serverSocket;

    /**
     * ProxyServer启动Server Socket
     * 
     * @throws IOException
     */
    public ProxyServer() throws IOException {
        serverSocket = new ServerSocket(PORT); //利用8000端口开启服务器socket
        executorService = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors() * POOLSIZE); //设置虚拟机可执行的线程数
        System.out.println("Proxy Server Started!\nPort 8000 is listening to you!\n");
    }

    /**
     *开启服务
     */
    public void service(){
        Socket socket = null;
        while (true) {
            try {
                socket = serverSocket.accept(); //接收线程
                executorService.execute(new Handler(socket)); //将线程移交给线程池处理
            } catch (IOException e) {
                e.printStackTrace();
                System.out.println("IO failed!");
            }
        }
    }

    /**
     * 
     * 主函数，开启代理服务器ProxyServer
     * @throws IOException
     */
    public static void main(String args[]) throws IOException{
        new ProxyServer().service();
    }
}
