package socket.file;

import java.io.File;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import FileSystem.FileServer2;



/**
 * SocketFileServer
 * 
 * @author ZSH
 *
 */

public class Server {
//	ServerSocket serverSocket = null;
	ServerSocket serverSocket; //服务器Socket
	private final int tcp_PORT = 2021; //TCP端口
	ExecutorService executorService; // 线程池 X
	static File root; //文件root目录
	final int POOLSIZE = 10; // 单个处理器线程池同时工作线程数目

	//构造函数
	public Server() throws IOException {
		serverSocket = new ServerSocket(tcp_PORT); // 创建服务器端套接字,（及进程队列数，默认长度为50）
		// 创建线程池
		// Runtime的availableProcessors()方法返回当前系统可用的java虚拟机处理器的数目
		// 由JVM根据系统的情况来决定线程的数量
		
		executorService = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors() * POOLSIZE);
		//System.out.println(Runtime.getRuntime().availableProcessors() * POOLSIZE);
		System.out.println("服务器启动成功。");
	}
	
	/**
	 * 
	 * @param args
	 * @throws SocketException
	 * @throws IOException
	 * D:
	 */
	/*
	public static void main(String[] args) throws SocketException, IOException{
	
		//传递root目录参数，并校验该目录是否有效
		if (args.length != 1) {
				System.err.println("Please input your root path!");
				return;
		}

		// 判断参数是否有效
		try {
			root = new File(args[0]);
			if (!root.isDirectory()) {
				System.err.println(root.getAbsolutePath() + " does not exist or is not a directory，please input again!");
				return;
				}
			} catch (Exception e) {
				e.printStackTrace();
				return;
				}

		System.out.println("Root : " + root.getAbsolutePath());
		
		new Server().service(); // 启动服务
	}*/
	public static void main(String[] args) throws SocketException, IOException {
		// pass root directory by String[] args
		if (args.length != 1) {
			System.err.println("Please input your root path!");
			return;
		}

		// 判断参数是否有效
		try {
			root = new File(args[0]);
			if (!root.isDirectory()) {
				System.err.println(root.getAbsolutePath() + " does not exist or is not a directory，please input again!");
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return;
		}

		System.out.println("Root : " + root.getAbsolutePath());
		String path = root.getAbsolutePath();
		
		// start server
		new Server().service(path);
	}

	/**
	 * service implements
	 */
	public void service(String path) {
		Socket socket = null; //方便进行垃圾回收
		while (true) {
			try {
				socket = serverSocket.accept(); // 等待用户连接
				executorService.execute(new Handler(socket,path)); // 把执行交给线程池来维护
			} catch (IOException e) {//如果客户端断开连接，则应捕获该异常，但不应中断整个while循环，使得服务器能继续与其他客户端通信
				e.printStackTrace();
			}
		}
	}
}
