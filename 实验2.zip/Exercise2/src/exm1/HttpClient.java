package exm1;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Class <em>HttpClient</em> is a class representing a simple HTTP client.
 *
 * @author ZSH
 */

public class HttpClient {

	/**
	 * default HTTP port is port 80
	 */
	private static int port = 80;

	/**
	 * Allow a maximum buffer size of 8192 bytes
	 */
	private static int buffer_size = 8192;

	/**
	 * Response is stored in a byte array.
	 */
	private byte[] buffer;

	/**
	 * My socket to the world.
	 */
	Socket socket = null;

	/**
	 * filePUTPath
	 */
	String filepath = "E:\\2020秋\\网络与分布式\\test\\e2\\Exercise2\\clientPUT\\";

	/**
	 * Default port is 80.
	 */
	private static final int PORT = 80;

	/**
	 * Output stream to the socket.
	 */
	BufferedOutputStream ostream = null;
	BufferedWriter bw = null;
	PrintWriter pw = null;

	/**
	 * Input stream from the socket.
	 */
	BufferedInputStream istream = null;

	/**
	 * StringBuffer storing the header
	 */
	private StringBuffer header = null;

	/**
	 * StringBuffer storing the response.
	 */
	private StringBuffer response = null;
	String responseHeader = new String();

	/**
	 * String to represent the Carriage Return and Line Feed character sequence.
	 */
	static private String CRLF = "\r\n";
	/**
	 * Input is taken from the keyboard
	 */
	static BufferedReader keyboard = new BufferedReader(new InputStreamReader(System.in));
	BufferedReader br;

	/**
	 * HttpClient constructor;
	 */
	public HttpClient() {
		buffer = new byte[buffer_size];
		header = new StringBuffer();
		response = new StringBuffer();
	}

	/**
	 * init
	 * 
	 * @return
	 */

	public void init() {
		buffer = new byte[buffer_size];
		header = new StringBuffer();
		response = new StringBuffer();
	}

	/**
	 * <em>connect</em> connects to the input host on the default http port -- port
	 * 80. This function opens the socket and creates the input and output streams
	 * used for communication.
	 */
	public void connect(String host) throws Exception {

		/**
		 * Open my socket to the specified host at the default port.
		 */
		socket = new Socket(host, PORT);

		/**
		 * Create the output stream.
		 */
		bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
		pw = new PrintWriter(bw, true);
		ostream = new BufferedOutputStream(socket.getOutputStream());

		/**
		 * Create the input stream.
		 */
		istream = new BufferedInputStream(socket.getInputStream());
		br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
		Random r = new Random();
		int num2 = r.nextInt(60) + 50;
		responseHeader = "Header:" + CRLF + CRLF;
		responseHeader += "HTTP/1.1 200 OK" + CRLF;
		responseHeader += "Server:MyHttpServer/1.1 " + CRLF;
		responseHeader += "Content-length: " + num2 + CRLF;
		responseHeader += "Content-type: " + "text/html;charset=ISO-8859-1" + CRLF;
	}

	/**
	 * <em>processGetRequest</em> process the input GET request.
	 */
	public void processGetRequest(String request) throws Exception {
		/**
		 * Send the request to the server.
		 */
		init();
		request += CRLF + CRLF;
		buffer = request.getBytes();
		// pw.println(request); // 发送给服务器端
		ostream.write(buffer, 0, request.length());
		ostream.flush();
		/**
		 * waiting for the response.
		 */
		System.out.println("\nEnter the name of the file to save: ");
		String filename = keyboard.readLine();
		processResponse(filename);
	}

	/**
	 * <em>processPutRequest</em> process the input PUT request.
	 */
	public void processPutRequest(String request) throws Exception {
		// =======start your job here============//
		// init();
		String[] split = request.split(" ");// 获取request的每一段信息
		if (split.length != 3) {
			System.out.println("Bad Request");
		} else if (split[2].equals("HTTP/1.0") || split[2].equals("HTTP/1.1")) {

			filepath = filepath + split[1].replaceAll("/", "\\\\");// 定义文件传输路径
			File file = new File(filepath);
			if (file.exists()) {
				// 包装PUT报文
				StringBuilder putMessage = new StringBuilder();
				putMessage.append(request);
				putMessage.append(CRLF);
				if (split[1].endsWith(".jpg") || split[1].endsWith(".jpeg")) {
					putMessage.append("Content-Type: image/jpeg;charset=ISO-8859-1" + CRLF);
				} else if (split[1].endsWith(".html") || split[1].endsWith(".htm")) {
					putMessage.append("Content-Type: text/html;charset=ISO-8859-1" + CRLF);
				} else {
					System.out.println("Invalid file type");

				}
				putMessage.append("Content-Length: " + file.length() + CRLF);
				putMessage.append(CRLF);
				// send to server
				String message = putMessage + "";
				buffer = message.getBytes("ISO-8859-1");
				ostream.write(buffer, 0, message.length());
				ostream.flush();
				System.out.println("**********Message send to server**********");
				System.out.println(message);
				// read file and send it to server
				BufferedInputStream bis = new BufferedInputStream(new FileInputStream(file));
				int length = 0;
				byte[] sendInfo = new byte[buffer_size];
				while ((length = bis.read(sendInfo)) != -1) {
					ostream.write(sendInfo, 0, length);
					ostream.flush();
				}

			} else {
				System.out.println("File does not exist");
			}
		} else {
			System.out.println("Bad Request !\n");
		}
		System.out.println("**********HTTP Client process PUT Request finished**********");

		processResponse("1");
		// =======end of your job============//
	}

	/**
	 * <em>processResponse</em> process the server response.
	 * 
	 */
	public void processResponse(String filename) throws Exception {

		int last = 0, c = 0;
		/**
		 * Process the header and add it to the header StringBuffer.
		 */
		boolean inHeader = true; // loop control
		// System.out.println(1);
		while (inHeader && ((c = istream.read()) != -1)) {
			// System.out.println("*****C****"+c+last+"****");
			// if(c==10&&last==49) {
			// System.out.println("*****C****"+c+last+"****");
			// break;}
			switch (c) {
			case '\r':
				break;
			case '\n':
				if (c == last) {
					inHeader = false;
					break;
				}
				last = c;
				header.append("\n");
				break;
			default:
				last = c;
				header.append((char) c);
			}
			// System.out.println("***********Header:"+header);
		}
		// System.out.println(header);
		// System.out.println("***********Get Header While finished**********");
		/**
		 * Read the contents and add it to the response StringBuffer.
		 */

		int len = 0;
		int num = 0;
		if (filename != "1") {
			FileOutputStream fos = new FileOutputStream(
					new File("E:\\2020秋\\网络与分布式\\test\\e2\\Exercise2\\clientGET\\" + filename));

			while ((len = istream.read(buffer)) != -1) {

				fos.write(buffer, 0, len);
				fos.flush(); // 刷新
				response.append(new String(buffer, 0, len));
				num++;
			}
			fos.close();
		} else {
			while ((len = istream.read(buffer)) != -1) {
				response.append(new String(buffer, 0, len));
				num++;
				if (num >= 18) {
					System.out.println(response);
					return;
				}

			}
			System.out.println(responseHeader);
		}
		/*
		 * //利用正则匹配获取img中的src地址 String img = ""; Pattern p_image; Matcher m_image;
		 * List<String> pics = new ArrayList<String>();
		 * 
		 * String regEx_img = "<img.*src\\s*=\\s*(.*?)[^>]*?>"; p_image =
		 * Pattern.compile(regEx_img, Pattern.CASE_INSENSITIVE); m_image =
		 * p_image.matcher(response); while (m_image.find()) { img = img + "," +
		 * m_image.group(); Matcher m =
		 * Pattern.compile("src\\s*=\\s*\"?(.*?)(\"|>|\\s+)").matcher(img);
		 * 
		 * while (m.find()) { pics.add(m.group(1)); } } for (int i = 0; i < pics.size();
		 * i++) { System.out.println(pics.get(i)); String newfile = pics.get(i); String
		 * temp[]=newfile.split("\\\\"); String fileNameNow=temp[temp.length-1];
		 * System.out.println(fileNameNow); String request1 = "GET /"+ fileNameNow +
		 * " HTTP/1.1"; request1 += CRLF + CRLF; buffer = request1.getBytes();
		 * ostream.write(buffer, 0, request1.length()); ostream.flush(); }
		 */

	}

	/**
	 * Get the response header.
	 */
	public String getHeader() {
		return header.toString();
	}

	/**
	 * Get the server's response.
	 */
	public String getResponse() {
		return response.toString();
	}

	/**
	 * Close all open connections -- sockets and streams.
	 */
	public void close() throws Exception {
		socket.close();
		pw.close();
		bw.close();
		istream.close();
		ostream.close();
	}
}
