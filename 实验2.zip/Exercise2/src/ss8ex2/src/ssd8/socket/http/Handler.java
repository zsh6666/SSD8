package ss8ex2.src.ssd8.socket.http;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;

public class Handler implements Runnable {

	private Socket socket;

	/**
	 * Output stream to the socket.
	 */
	BufferedOutputStream sout = null;

	/**
	 * Input stream from the socket.
	 */
	BufferedInputStream sin = null;

	/**
	 * StringBuffer storing the header
	 */
	private StringBuffer header = null;

	/**
	 * StringBuffer storing the response.
	 */
	/**
	 * String to represent the Carriage Return and Line Feed character sequence.
	 */
	static private String CRLF = "\r\n";
	static private String rootpath = "E:/test";
	/**
	 * Allow a maximum buffer size of 8192 bytes
	 */
	private static int buffer_size = 8192;

	/**
	 * Response is stored in a byte array.
	 */
	private byte[] buffer;

	public Handler(Socket socket) {
		this.socket = socket;
		buffer = new byte[buffer_size];
		header = new StringBuffer();
	}
/**
 * 初始化输入输出流
 * @throws IOException
 */
	public void initStream() throws IOException {
		sin = new BufferedInputStream(socket.getInputStream());
		sout = new BufferedOutputStream(socket.getOutputStream());
	}
/**
 * 基本动作
 */
	public void run() {
		try {
			initStream();
			int last = 0, c = 0;
			/**
			 * Process the header and add it to the header StringBuffer.
			 */
			boolean moreMsg = true; // loop control
			ArrayList<String> headers = new ArrayList<String>(); // 创建一个数组存放头部信息
			while (moreMsg && ((c = sin.read()) != -1)) {
				switch (c) {
				case '\r':
					break;
				case '\n':
					if (c == last) {
						moreMsg = false;
						break;
					}
					last = c;
					header.append("\n");
					headers.add(header.toString());
					header = new StringBuffer();
					break;
				default:
					last = c;
					header.append((char) c);
					break;
				}
			}
			System.out.println();
			for(String info:headers) {
				System.out.print(info);//将收到的HTTP请求的Header逐行输出
			}
				
				boolean allowPUTreq = true;
	            File file = null;
	            long filesize = 0;
				String filename = "";
				for (String info : headers) { // 在头部列表中寻找信息
					if (info.toUpperCase().startsWith("GET")) {
						allowPUTreq = false;
						System.err.println(info);
						getHandler(info);
						break;
					} else if (info.toUpperCase().startsWith("PUT") && info.contains("Content-length")) {
						String[] list;
						list= info.split(" ");
						for(int i=0;i<list.length;i++){
							System.err.println(list[i]+" ");
							//五大参数,缺一不可
							//PUT 文件名 协议/版本 Content-length: 长度值
						}
						if (list.length != 5) {
							allowPUTreq = false;
							String response = "HTTP/1.1 400 Bad Request" + CRLF
									+ CRLF; // 如果list长度不是5则返回错误请求
							buffer = response.getBytes();
							sout.write(buffer, 0, response.length());
							sout.flush();
							break;
						} else {
							filename = list[1];
							filename.replace('\\', '/');
							if(filename.charAt(0)!='/') filename = "/" + filename;//进行容错处理，允许省略前面的标号
							file = new File(filename);
						filesize = Long.parseLong(list[4].trim(), 10);
					}
					}else{
						allowPUTreq = false;
						String response = "HTTP/1.1 400 Bad Request" + CRLF
								+ CRLF; // 如果list长度不是5则返回错误请求
						buffer = response.getBytes();
						sout.write(buffer, 0, response.length());
						sout.flush();
						break;
					}
				}
				if(allowPUTreq){
					if(filesize == 0){ //文件大小为0的情况
						file = new File(rootpath+filename);
						String code = "201 Created";
							if(file != null && file.exists()) code = "200 OK";
						FileWriter fw = new FileWriter(file);
						fw.write("");
						fw.flush();
						fw.close();
						String response = "HTTP/1.1 " + code +CRLF;
						response += "Content-Location: " + filename + CRLF
								+ CRLF;
						buffer = response.getBytes();
						sout.write(buffer,0,response.length());
						sout.flush();
					}
					else{  //如果文件大小不为0，即文件有内容
						file = new File(rootpath+filename);
						String code = "201 Created";
							if(file != null && file.exists()) code = "200 OK";
						ArrayList<Byte> bytelist = new ArrayList<Byte>();
						int a=0;
						while((a=sin.read())!=-1){  //读取文件内容 
							byte b = (byte)a;
							bytelist.add(new Byte(b)); //将文件内容存起来
							if(bytelist.size() == filesize){ 
								break;
							}
						}
						byte[] bytes = new byte[bytelist.size()];
						for(int i=0;i<bytelist.size();i++){
							bytes[i] = bytelist.get(i).byteValue();
						}
						BufferedOutputStream fout = new BufferedOutputStream(new FileOutputStream(file));
						fout.write(bytes);
						fout.flush();
						fout.close();
						String filetype = getFileType(filename);
						String response = "HTTP/1.1 " + code + CRLF;
						response += "Content-Type: " + filetype + CRLF;
						response += "Content-Location: " + filename + CRLF
								+ CRLF;
						buffer = response.getBytes();
						sout.write(buffer, 0, response.length());
						sout.flush();
						}
					}
			} catch (IOException e) {
			e.printStackTrace();
		}finally{
			if(null != socket){
				try{
					socket.close();
				}catch(IOException e){
					e.printStackTrace();
				}
			}
		}

	}


/**
 * 处理GET请求的函数
 * @param info
 * @return
 * @throws IOException
 */
	private boolean getHandler(String info) throws IOException {
		String filename=""; // 存储GET语句中的信息
		long fileSize = 0;
		File file=null;
		String[] list;
		list = info.split(" ");
		filename = list[1];
		filename.replace('\\', '/');
		if(filename.charAt(0)!='/') filename = "/" + filename;//进行容错处理，允许省略前面的标号
		file = new File(rootpath + filename);
		System.err.println(file);
		if (!file.exists()) {
			String response = "HTTP/1.1 404 NOT FOUND" + CRLF + CRLF; // 找不到该文件
			buffer = response.getBytes();
			sout.write(buffer, 0, response.length());
			sout.flush();
			return false;
		} else {
			String fileType;
			fileType = getFileType(filename); // 获取文件的类型
			fileSize = file.length(); // 获得文件大小
			System.out.println("该文件大小为：" + fileSize);
			String response = "HTTP/1.1 200 OK" + CRLF;
			response += "Content-type: " + fileType + CRLF;
			response += "Content-length: " + fileSize + CRLF+CRLF;
			buffer = response.getBytes();
			sout.write(buffer, 0, response.length());
			//System.out.println("正在传输");
			 try {
				 fOut(file);//将文件传输到服务器
		        } catch (Exception e) {
		            e.printStackTrace();
		        }
		        sout.flush();
		    }return true;
	}
/**
 * 根据文件名确定文件类型，之区别htm(l) txt 和 jpg格式
 * @param filename
 * @return
 */
	private String getFileType(String filename) {
		// TODO Auto-generated method stub
		String fileType = "others";
		if(filename.indexOf(".htm")!=-1||filename.indexOf(".txt")!=-1) fileType = "text/html";
		 else if(filename.indexOf(".jpg")!=-1) fileType = "image/jpeg";
		return fileType;
	}
/**
 * 将指定文件输出给服务器
 * @param file
 * @throws IOException
 */
	private void fOut(File file) throws IOException {
		buffer = new byte[buffer_size];
		int reads = 0;
		BufferedInputStream fin = new BufferedInputStream(new FileInputStream(file));
		// 读取file内容
		System.out.println("开始传输");
		while ((reads = fin.read(buffer)) != -1) {
			sout.write(buffer, 0, reads);
		}
		fin.close();
	}

}
