package ss8ex2.src.ssd8.socket.http;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.net.Socket;

/**
 * Class <em>HttpClient</em> is a class representing a simple HTTP client.
 *
 * @author wben
 */

public class HttpClient {

	/**
	 * default HTTP port is port 80
	 */
	private static int port = 80;

	/**
	 * Allow a maximum buffer size of 8192 bytes
	 */
	private static int buffer_size = 8192;

	/**
	 * Response is stored in a byte array.
	 */
	private byte[] buffer;

	/**
	 * My socket to the world.
	 */
	Socket socket = null;

	/**
	 * Default port is 80.
	 */
	private static final int PORT = 80;

	/**
	 * Output stream to the socket.
	 */
	BufferedOutputStream ostream = null;

	/**
	 * Input stream from the socket.
	 */
	BufferedInputStream istream = null;

	/**
	 * StringBuffer storing the header
	 */
	private StringBuffer header = null;

	/**
	 * StringBuffer storing the response.
	 */
	private StringBuffer response = null;

	/**
	 * String to represent the Carriage Return and Line Feed character sequence.
	 */
	static private String CRLF = "\r\n";
	static private String rootpath = "";//客户端直接相对路径即可，不再更改

	/**
	 * HttpClient constructor;
	 */
	public HttpClient() {
		buffer = new byte[buffer_size];
		header = new StringBuffer();
		response = new StringBuffer();
	}

	/**
	 * <em>connect</em> connects to the input host on the default http port --
	 * port 80. This function opens the socket and creates the input and output
	 * streams used for communication.
	 * @param host 主机地址
	 * @throws java.lang.Exception 
	 */
	public void connect(String host) throws Exception {

		/**
		 * Open my socket to the specified host at the default port.
		 */
		socket = new Socket(host, PORT);

		/**
		 * Create the output stream.
		 */
		ostream = new BufferedOutputStream(socket.getOutputStream());

		/**
		 * Create the input stream.
		 */
		istream = new BufferedInputStream(socket.getInputStream());
	}

	/**
	 * <em>processGetRequest</em> process the input GET request.
	 * @param request 
	 * @throws java.lang.Exception 
	 */
	public void processGetRequest(String request) throws Exception {
		/**
		 * Send the request to the server.
		 */
		request += CRLF + CRLF;
		buffer = request.getBytes();
		ostream.write(buffer, 0, request.length());
		ostream.flush();
		/**
		 * waiting for the response.
		 */
		processResponse();
	}

	/**
	 * <em>processPutRequest</em> process the input PUT request.
	 * @param request 
	 * @throws java.lang.Exception 
	 */
	public void processPutRequest(String request) throws Exception {
		// =======start your job here============//
		String[] list = request.split(" "); 
		File file = null;
		String filename = list[1]; 
		file = new File(filename);
		if ((list.length) == 3) {
			
			if (file.exists()) {
				request +=" " + "Content-length: " + file.length() + CRLF + CRLF;
			} else{
				request += " "  +  "Content-length: 0" + CRLF + CRLF;
			}
		} else{
			request += " "  +  "Content-length: 0" + CRLF + CRLF;
		}
		
		buffer = request.getBytes();
		ostream.write(buffer, 0, request.length());
		ostream.flush();
		if ((file.exists()) && file != null) { 
			BufferedInputStream ipstream = new BufferedInputStream(
					new FileInputStream(file));
			System.out.println("文件长度："+file.length());
			while(true){
				
				int read=0;
				if(ipstream!=null){
					read = ipstream.read(buffer);
				}
				if(read==-1){
					ipstream.close();
					break;
				}
				ostream.write(buffer,0,read);
				System.out.println("本次传输" + read + "字节");
			}
			System.out.println("上传完毕");
			ostream.flush();
		}
		ostream.flush();
		processResponse(); // 接受服务器返回的信息
		// =======end of your job============//

	}

	/**
	 * <em>processResponse</em> process the server response.
	 * @throws java.lang.Exception
	 */
	public void processResponse() throws Exception {
		int last = 0, c = 0;
		/**
		 * Process the header and add it to the header StringBuffer.
		 */
		boolean moreMsg = true; // loop control
		while (moreMsg && ((c = istream.read()) != -1)) {
			switch (c) {
			case '\r':
				break;
			case '\n':
				if (c == last) {
					moreMsg = false;
					break;
				}
				last = c;
				header.append("\n");
				break;
			default:
				last = c;
				header.append((char) c);
			}
		}

		/**
		 * Read the contents and add it to the response StringBuffer.
		 */
		while (istream.read(buffer) != -1) {
			response.append(new String(buffer, "iso-8859-1"));
		}
	}

	/**
	 * Get the response header.
	 * @return 
	 */
	public String getHeader() {
		return header.toString();
	}

	/**
	 * Get the server's response.
	 * @return 
	 */
	public String getResponse() {
		return response.toString();
	}

	/**
	 * Close all open connections -- sockets and streams.
	 * @throws java.lang.Exception 鎶涘嚭涓�涓猠xception寮傚父
	 */
	public void close() throws Exception {
		socket.close();
		istream.close();
		ostream.close();
	}
}
