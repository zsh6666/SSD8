package exm1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.concurrent.TimeUnit;

/**
 * Class <em>Client</em> is a class representing a simple HTTP client.
 *
 * @author ZSH
 */

public class Client {

	/**
	 * default HTTP port is port 80
	 */
	private static int port = 80;

	/**
	 * Allow a maximum buffer size of 8192 bytes
	 */
	private static int buffer_size = 8192;

	/**
	 * The end of line character sequence.
	 */
	private static String CRLF = "\r\n";

	/**
	 * filePutPath
	 */
	static String filepath = "E:\\2020秋\\网络与分布式\\test\\e2\\Exercise2\\clientPUT\\";
	static String fileGet = "E:\\2020秋\\网络与分布式\\test\\e2\\Exercise2\\clientGET\\";

	/**
	 * Input is taken from the keyboard
	 */
	static BufferedReader keyboard = new BufferedReader(new InputStreamReader(System.in));

	/**
	 * Output is written to the screen (standard out)
	 */
	static PrintWriter screen = new PrintWriter(System.out, true);

	public static void main(String[] args) throws Exception {
		try {
			/**
			 * Create a new HttpClient object.
			 */
			HttpClient myClient = new HttpClient();

			/**
			 * Parse the input arguments.
			 */
			if (args.length != 1) {
				System.err.println("Usage: Client <server>");
				System.exit(0);
			}

			/**
			 * Connect to the input server
			 */
			myClient.connect(args[0]);

			/**
			 * Read the get request from the terminal.
			 */
			screen.println("The file PUT path is:" + filepath);
			screen.println("The file GET path is:" + fileGet);
			screen.println(args[0] + " is listening to your request:");
			String request = null;

			request = keyboard.readLine();

			// 如果没有指定HTTP版本，则会自动设置为HTTP 1.1
			if (request.toUpperCase().indexOf("HTTP") == -1)
				request += " HTTP/1.1";

			if (request.toUpperCase().startsWith("GET")) {
				/**
				 * Ask the client to process the GET request.
				 */
				myClient.processGetRequest(request);

			} else if (request.toUpperCase().startsWith("PUT")) {
				/**
				 * Ask the client to process the PUT request.
				 */
				String[] split = request.split(" ");// 获取request的每一段信息
				if (split.length != 3) {
					System.out.println("Bad Request! \n");
					myClient.close();
					return;
				} else if (split[2].equals("HTTP/1.0") || split[2].equals("HTTP/1.1")) {

					filepath = filepath + split[1].replaceAll("/", "\\\\");// 定义文件传输路径
					File file = new File(filepath);
					if (!file.exists()) {
						System.out.println("File does not exist");
						myClient.close();
						return;
					} else {
						myClient.processPutRequest(request);
						String response1 = myClient.getResponse();

						myClient.close();
						return;
					}
				}

			} else {
				/**
				 * Do not process other request.
				 */
				screen.println("Bad request! \n");
				myClient.close();
				return;
			}

			/**
			 * Get the headers and display them.
			 */
			screen.println("Header: \n");
			screen.print(myClient.getHeader() + "\n");
			screen.flush();

			if (request.toUpperCase().startsWith("GET")) {
				/**
				 * Ask the user to input a name to save the GET resultant web page.
				 */
				// screen.println();
				// screen.print("Enter the name of the file to save: ");
				// screen.flush();
				// String filename = keyboard.readLine();
				// FileOutputStream outfile = new FileOutputStream(filename);

				/**
				 * Save the response to the specified file.
				 */
				String response = myClient.getResponse();
				// System.out.println(response.getBytes());
				// outfile.write(response.getBytes());
				screen.println("File saved successfully!");
				screen.println("Connection is closed!");
				// outfile.flush();
				// outfile.close();
			}

			/**
			 * Close the connection client.
			 */
			myClient.close();
		} catch (

		Exception e) {
			e.printStackTrace();
		}
	}
}
