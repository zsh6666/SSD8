package proxy;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.URL;
import java.util.Scanner;

/**
 * Handler是一个表示工作线程的类，处理连接操作。
 * 
 * @author ZSH
 * 
 */
public class Handler implements Runnable {
	/**
	 * 用于处理与指定客户端的连接的套接字
	 */
    private Socket socket;
    /**
     * 处理请求并从目标获取响应
     */
    private RequestProcessor requestProcessor;
    private byte[] buffer;
    private static int buffer_size = 8192;
    private static String CRLF = "\r\n";

    private BufferedReader cin = null;
    private BufferedOutputStream cout = null;

    /**
     * 初始化输入输出流
     *
     * @throws IOException
     */
    public void initStream() throws IOException {
        cin = new BufferedReader(new InputStreamReader(socket.getInputStream())); //设置输入流
        cout = new BufferedOutputStream(socket.getOutputStream()); //设置输出流
    }

    /**
     * Handler的构造函数.
     * @param socket
     */
    public Handler(Socket socket) {
        this.socket = socket;
        buffer = new byte[buffer_size];
        this.requestProcessor = new RequestProcessor();
    }

    @Override
    public void run() {
        try {
            initStream();
            String info = null;

            while ((info = cin.readLine()) != null) {
                if (info.toLowerCase().startsWith("get")) {
                    getHandler(info);
                } else if (info.toLowerCase().startsWith("from") || info.toLowerCase()
                        .startsWith("user-agent")) {//此处什么也不做
                } else {
                    badRequest();//提示错误信息
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (socket != null) {
                try {
                    socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * 返回 400 Bad Request
     *
     * @throws IOException
     */
    private void badRequest() throws IOException {
        String response = "HTTP/1.0 400 Bad Request" + CRLF + CRLF;
        buffer = response.getBytes();
        cout.write(buffer, 0, response.length());
        cout.flush();
    }

    /**
     * 处理GET请求
     *
     * @param info
     * @return 
     * @throws Exception
     */
    private boolean getHandler(String info) throws Exception {
        URL url = null;
        String[] reqs = info.split(" ");
        int port = 80;
        if (!(reqs.length == 3)) {
            badRequest();
            return false;
        } else {

            String informs[] = reqs[1].split(":");
            if(informs.length >= 3){
            	String portString[] = informs[2].split("/");
            	port = Integer.parseInt(portString[0]);
            }
            url=new URL(reqs[1]); //获取目标http的URL地址
        	getReqProc(url, port); //向目标http发送请求
            getResProc();
        }
        return true;
    }


    /**
     * 处理请求.
     * @param url
     * @throws Exception
     */
    private void getReqProc(URL url, int port) throws Exception {
        requestProcessor.connect(url.getHost(), port); //建立连接
        String request = "GET " + url + " HTTP/1.0"; //包装请求（类似于Client）
        requestProcessor.processGetRequest(request, url.getHost(),port);
    }

    /**
     * 从请求处理器获取响应.
     *
     * @throws IOException
     */
    private void getResProc() throws IOException {
        String header = requestProcessor.getHeader() + "\n";
        String body = requestProcessor.getResponse(); //接收响应实体
        System.out.println("****************Response body:******************");
        System.out.println(body); //将响应的文件内容展示在控制台
        System.out.println("****************Response end******************");
        System.out.println();
        buffer = header.getBytes();
        cout.write(buffer, 0, header.length());
        cout.write(body.getBytes("iso-8859-1"));

        cout.flush();
    }

}

