package ss8ex2.src.ssd8.socket.http;

import java.io.IOException;
import java.net.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class HttpServer {
	
		private final int port = 80;

		ServerSocket sersocket;
		ExecutorService executorService;
		final int POOL_SIZE = 4;
		
		
		public HttpServer() throws IOException {
		
			sersocket = new ServerSocket(port); 

			//serverSocket.setSoTimeout(30000);
			executorService = Executors.newFixedThreadPool(Runtime.getRuntime()
					.availableProcessors() * POOL_SIZE);
			System.out.print("Server startup!");
		}
		
		public static void main(String[] args)throws InterruptedException, IOException{
			new HttpServer().servic(); 
		}
		
		public void servic(){
			Socket socket = null;
			while(true){
			try{
					/**
					 * Wait and pull out the user connection.
					 */
					socket = sersocket.accept(); 
					/**
					 * Create a worker thread for the client connection.
					 */
					Thread work = new Thread(new Handler(socket));
					work.start(); 
			}catch(IOException e){
				e.printStackTrace();
			}
			}
		}
}
